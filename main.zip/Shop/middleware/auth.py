from django.shortcuts import redirect



def auth_middleware(get_response):
    # One-time configuration and initialization.

    def middleware(request):


        if request.session.get('user_id') is None:
            return_url = request.META['PATH_INFO']
            print(return_url)
            return redirect(f'/shop/login/?returnUrl={return_url}')
        response = get_response(request)
        return response

    return middleware