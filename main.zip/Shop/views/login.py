from django.shortcuts import render, redirect,HttpResponseRedirect

from Shop.models.customer import Customer


from django.contrib import messages
from django.contrib.auth.hashers import check_password
from django.views import View
from Shop.models.cart import Cartview


class Login(View):
    return_url = None
    def get(self,request):

        Login.return_url = request.GET.get('returnUrl')
        print(Login.return_url)
        return render(request,'Shop/login.html')
    def post(self,request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        value = {'email': email}
        try:
            user = Customer.objects.get(email=email)
            flag = check_password(password, user.password)

            if flag:
                request.session['user_id'] = user.id
                request.session['email'] = user.email
                if Login.return_url:
                    cart_counter = Cartview.objects.filter(customer=user)
                    request.session['cart_counter'] = len(cart_counter)
                    return HttpResponseRedirect(Login.return_url)
                else:
                    cart_counter = Cartview.objects.filter(customer=user)
                    request.session['cart_counter'] = len(cart_counter)
                    Login.return_url = None
                    return redirect('index')
            else:
                messages.error(request, 'user name or password not match')
                return render(request, 'Shop/login.html', value)
        except:
            messages.error(request, 'this user name is not exist')
            return render(request, 'Shop/login.html', value)

def logout(request):
    request.session.clear()
    return  redirect('login')