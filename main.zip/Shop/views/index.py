# from django.http import HttpResponse
from django.shortcuts import render, redirect
# from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.models import User
# from django.contrib.auth import authenticate, login, logout
from Shop.models.category import Category
from Shop.models.customer import Customer
from Shop.models.product import Product
from Shop.models.cart import Cartview

# from django.contrib.auth.hashers import check_password, make_password
from django.views import View


class Index(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        categorys = Category.objects.all()

        category_id = request.GET.get('category_id')
        if category_id:

            products = Product.objects.filter(category=category_id)
        else:
            products = Product.objects.all()

        data = {}
        data['products'] = products
        data['categorys'] = categorys

        return render(request, 'Shop/index.html', data)

    def post(self, request):
        if request.session.get('user_id'):
            customer = request.session.get('user_id')
            product = request.POST.get('product')
            cart = Cartview.objects.filter(customer=customer)
            qty= list(Cartview.objects.filter(customer=customer, product=product))






            if qty:
                 Cartview.objects.filter(customer=customer, product=product).update(quantity=qty[0].quantity+1)

            else:

                cart = Cartview(product=Product(id=int(product)),customer=Customer(id=customer),quantity=1)
                cart.save()

            cart_counter = Cartview.objects.filter(customer=customer)
            request.session['cart_counter'] = len(cart_counter)






        else:
            product = request.POST.get('product')
            remove = request.POST.get('remove')
            cart = request.session.get('cart')

            if cart:
                quantity = cart.get(product)
                if quantity:
                    if remove:
                        cart[product] = quantity - 1
                        if cart[product] == 0:
                            del cart[product]
                    else:
                        cart[product] = quantity + 1
                else:
                    cart[product] = 1
            else:
                cart = {}
                cart[product] = 1

            request.session['cart'] = cart

        return redirect('index')
