from django.shortcuts import render,redirect
from django.views import View
from Shop.models.product import Product
from Shop.models.cart import Cartview
from django.shortcuts import HttpResponse,HttpResponseRedirect
from Shop.models.customer import Customer




class Cart(View):
    def get(self, request):
        if request.session.get('user_id'):
            customer = request.session.get('user_id')
            cart_items = Cartview.get_orders_by_customer(customer)
            # print('cart from database',cart_items)
            # for i in cart_items:
            #     print('customer',i.customer)
            #     print('productname',i.product.name)
            #     print('productprice', i.product.price)



        else:
            if request.session.get('cart') is None:
                request.session['cart'] = {}
            product_ids = list(request.session.get('cart').keys())
            cart_items = Product.get_products_by_id(product_ids)

        return render(request, 'Shop/cart.html', {'cart_items': cart_items})
        # return HttpResponse('hello cart')
    def post(self,request):
        if request.session.get('user_id'):
            customer = request.session.get('user_id')
            product = request.POST.get('product')
            itemquantity = request.POST.get('qty')

            cart = Cartview.objects.filter(customer=customer)
            qty = list(Cartview.objects.filter(customer=customer, product=product))
            print(type(itemquantity))





            if int(itemquantity)>0:

                 Cartview.objects.filter(customer=customer, product=product).update(quantity=itemquantity)

            else:

                Cartview.objects.filter(customer=customer, product=product).delete()


            cart_counter = Cartview.objects.filter(customer=customer)
            request.session['cart_counter'] = len(cart_counter)
            return HttpResponseRedirect('/shop/cart/')
        else:

            product = request.POST.get('product')
            itemquantity = request.POST.get('qty')
            print(type(product))

            # print(request.session['cart'])
            # print(request.session['cart'][product])
            # request.session['cart'][product] = int(itemquantity)
            # print(request.session['cart'][product])
            # return HttpResponse('hello cart')
            cart = request.session.get('cart')
            if int(itemquantity) > 0:

                cart[product] = int(itemquantity)

            else:
                del cart[product]
            request.session['cart']=cart



            return HttpResponseRedirect('/shop/cart/')