from django.shortcuts import render,redirect
from django.views import View
from Shop.models.product import Product
from Shop.models.customer import Customer
from Shop.models.orders import Order
from Shop.models.cart import Cartview
class Checkout(View):
    def get(self,request):
        if request.session['cart'] is not None:
            customer = request.session.get('user_id')
            cart = request.session.get('cart')
            product_ids = list(cart.keys())

            for item in product_ids:
                # print('value',type(request.session['cart'][item]))

                cart = Cartview.objects.filter(customer=customer)
                qty = list(Cartview.objects.filter(customer=customer, product=int(item)))

                if cart:

                    if qty:
                        Cartview.objects.filter(customer=customer, product=int(item)).update(quantity=qty[0].quantity + request.session['cart'][item])

                    else:

                        cart = Cartview(product=Product(id=int(item)), customer=Customer(id=customer), quantity=request.session['cart'][item])
                        cart.save()

                    cart_counter = Cartview.objects.filter(customer=customer)
                    request.session['cart_counter'] = len(cart_counter)
        request.session['cart'] = {}
        
        return render(request,'Shop/checkout.html')

    def post(self,request):
        # cart = request.session.get('cart')
        # product_ids = list(cart.keys())

        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('user_id')
        # cart = request.session.get('cart')
        # product_ids = list(cart.keys())
        # ordered_items = Product.get_products_by_id(product_ids)
        cart_items = Cartview.get_orders_by_customer(customer)
        # print(address,phone,customer)
        for item in cart_items:
            order= Order(product = Product(id=item.product.id),customer =Customer(id=customer),quantity = item.quantity,price = item.product.price,
                                                                                address = address,phone = phone)
            order.place_order()
        Cartview.objects.filter(customer = customer).delete()
        request.session['cart_counter']=0
        request.session['cart']={}
        return redirect('orders')
