from django.shortcuts import render, redirect

from Shop.models.customer import Customer


from django.contrib import messages
from django.contrib.auth.hashers import make_password
from django.views import View


class Signup(View):

    def get(self,request):
        return render(request, 'Shop/signup.html')

    def post(self,request):
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        password1 = request.POST.get('password1')
        password2 = request.POST.get('password2')
        error_message = None
        value = {'first_name': first_name, 'last_name': last_name, 'email': email, 'phone': phone}
        customer_data = {'first_name': first_name, 'last_name': last_name, 'email': email, 'phone': phone,'password1':password1,'password2':password2}
        customer = Customer(first_name=first_name, last_name=last_name, email=email, phone=phone, password=password1)
        error_message= self.user_validation(customer_data)
        if not error_message:
            customer.password = make_password(customer.password)
            customer.save()
            return redirect('index')
        else:
            messages.error(request,error_message)
            return render(request,'Shop/signup.html',value)

    def user_validation(self, customer_data):
        error_message = None
        print('uservalidation')
        print(len(customer_data['first_name']))
        if len(customer_data['first_name']) < 4:
            error_message = 'First Name must be 4 char long or more'

        elif len(customer_data['last_name']) < 4:
            error_message = 'Last Name must be 4 char long or more'


        elif len(customer_data['phone']) < 10:
            error_message = 'Phone Number must be 10 char Long'


        elif len(customer_data['password1']) < 6:
            error_message = 'Password must be 6 char long'

        elif customer_data['password1'] != customer_data['password2']:
            error_message = 'Password is not match'

        elif Customer.objects.filter(email=customer_data['email']):
            error_message = 'email is already exist'

        return error_message
