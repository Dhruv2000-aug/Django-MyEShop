from django.shortcuts import render,redirect
from django.views import View
from Shop.models.orders import Order




class Orders(View):

    def get(self,request):
        user = request.session.get('user_id')

        orders = Order.get_orders_by_customer(user)
        return render(request,'Shop/orders.html',{'orders':orders})
