from django import template

register = template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(product,cart):
    # keys = cart.keys()
    # for id in keys:
    #     if product.id == int(id):
    #         return True
    # return False
    if cart.get(str(product.id)) is not None:
            return True
    return False


@register.filter(name='cart_quantity')
def cart_quantity(product,cart):
    return cart.get(str(product.id))


@register.filter(name='temp_price_total')
def temp_price_total(product,cart):
    return product.price * cart_quantity(product,cart)

@register.filter(name='user_price_total')
def user_price_total(product,quantity):
    return product * quantity


@register.filter(name='temp_cart_price_total')
def temp_cart_price_total(item,cart):

    total = 0
    for p in item:
        total += temp_price_total(p,cart)

    return total


@register.filter(name='user_cart_price_total')
def user_cart_price_total(item):
    total = 0
    for p in item:
        total += user_price_total(p.product.price, p.quantity)

    return total