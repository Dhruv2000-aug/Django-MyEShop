from django.db import models
from .product import Product
from .customer import Customer



class Cartview(models.Model):
    product = models.ForeignKey(Product,
                                on_delete=models.CASCADE)
    customer = models.ForeignKey(Customer,
                                 on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)

    @staticmethod
    def get_orders_by_customer(user):
        return Cartview.objects.filter(customer=user)



