from django.contrib import admin

from Shop.models.category import Category
from Shop.models.customer import Customer
from Shop.models.product import Product
from Shop.models.orders import Order
from Shop.models.cart import Cartview




class AdminProduct(admin.ModelAdmin):
    list_display = ['name','price','category']


admin.site.register(Product,AdminProduct)
admin.site.register(Category)
admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(Cartview)




