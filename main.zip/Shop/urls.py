from django.contrib import admin
from django.urls import path
from Shop.views import index
from Shop.views import login
from Shop.views import signup
from Shop.views import cart
from Shop.views import checkout
from Shop.views import orders
from django.conf import settings
from django.conf.urls.static import static
from Shop.middleware.auth import auth_middleware

urlpatterns = [

    path('',index.Index.as_view(), name='index'),
    path('signup/', signup.Signup.as_view(), name='signup'),
    path('login/', login.Login.as_view(), name='login'),
    path('logout/',login.logout,name='logout'),
    path('cart/',cart.Cart.as_view(),name='cart'),
    path('checkout/',auth_middleware(checkout.Checkout.as_view()),name='checkout'),
    path('orders/',auth_middleware(orders.Orders.as_view()),name='orders')



]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)